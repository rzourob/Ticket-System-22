<?php

namespace App\Http\Controllers\Maintenance;

use App\Http\Controllers\Controller;
use App\Models\Department\Department;
use App\Models\Device\Device;
use App\Models\Maintenance\MaintenanceRequest;
use App\Models\SubDepartment\SubDepartment;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use  Yajra\DataTables\DataTables;

class MaintenanceRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // $maintenancerequests = MaintenanceRequest::get();
        // return response()-> view('maintenances.index',['maintenancerequests' => $maintenancerequests]);
    }

    public function getdeviceit()
    {
        //
        $devices = Device::where('deviceTypes', 2)->get();

        return response()-> view('maintenances.getdeviceit',['devices' => $devices]);
    }

    public function iTRequest()

    {
        $devices = Device::where('deviceTypes', 2)->get();

        return DataTables::of($devices)

            // ->addColumn('record_select', 'admin.users.data_table.record_select')tiket_no

            // ->addColumn('tiket_no', function (MaintenanceRequest $maintenanceRequest) {
            //     return view('maintenances.data_table.tiket_no', compact('maintenanceRequest'));
            // })

            // ->addColumn('deviceTypes', function (MaintenanceRequest $maintenanceRequest) {
            //     return view('maintenances.data_table.deviceTypes', compact('maintenanceRequest'));
            // })

            // ->addColumn('title', function (MaintenanceRequest $maintenancerequest) {
            //     return view('maintenances.data_table.title', compact('maintenancerequest'));
            // })

            // ->addColumn('content', function (maintenanceRequest $maintenanceRequest) {
            //     return view('maintenances.data_table.content', compact('maintenanceRequest'));
            // })

            // ->addColumn('department_id', function (maintenanceRequest $maintenanceRequest) {
            //     return view('maintenances.data_table.departments', compact('maintenanceRequest'));
            // })

            // ->addColumn('sub_department_id', function (maintenanceRequest $maintenanceRequest) {
            //     return view('maintenances.data_table.subdepartments', compact('maintenanceRequest'));
            // })

            // ->addColumn('active', function (maintenanceRequest $maintenanceRequest) {
            //     return view('maintenances.data_table.active', compact('maintenanceRequest'));
            // })

            ->addColumn('deviceTypes', function (MaintenanceRequest $maintenanceRequest) {
                return view('maintenances.data_table.deviceTypes', compact('maintenanceRequest'));
            })

            // ->editColumn('created_at', function (maintenanceRequest $maintenanceRequest) {
            //     return $maintenanceRequest->created_at->format('Y-m-d');
            // })
            ->addColumn('actions', 'maintenances.data_table.actions')
            ->rawColumns(['actions'])
            ->toJson();

    }// end of data


    public function getdeviceMedical()
    {
        //
        $maintenancerequests = MaintenanceRequest::get();
        return response()-> view('maintenances.getdeviceMedical',['maintenancerequests' => $maintenancerequests]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $subdepartments = SubDepartment::where('active', true)->get();
        $departments = Department::where('active', true)->get();
        $devices = Device::where('active', true)->get();
        return response()->view('maintenances.create',['subdepartments'=>$subdepartments,'departments'=>$departments,'devices'=>$devices]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $year = Carbon::now()->format('Y');
        $number = 1;
        $lastRecord = MaintenanceRequest::latest()->first();
        if ($lastRecord) {
            $lastRecord = explode('-', $lastRecord->tiket_no);
            $lastRecordFileNo = $lastRecord[2];
            if ($lastRecord[1] !== Carbon::now()->format('Y')) {
                $number = 1;
            } else {
                $number = $lastRecordFileNo + 1;
            }
        }

        $tiket_no = 'HBK-' . $year . '-' . $number;

         $validator = Validator($request->all(), [

            //  'name' => 'required| string',
            //  'sn' => 'required| string|min:3| max:35',
            //  'company' => 'required|string',
            //  'device_type' => 'required|string',
            //  'supplier' => 'required|string'

         ],[

            // 'name.required' =>'الرجاء ادخال اسم الجهاز الطبي',
            // 'sn.required' => 'الرجاء ادخال السيريل نمبر الجهاز',
            // 'company.required' => 'الرجاء ادخال اسم الشركة المصنعة',
            // 'device_type.required' => 'الرجاء ادخال اسنوع الجهاز الطبي',
            // 'supplier.required' => 'الرجاء ادخال الموردة',
            

         ]);
        if (!$validator->fails()) {

            $maintenancerequests = new maintenancerequest();

                $maintenancerequests->tiket_no = $tiket_no;
                $maintenancerequests->title = $request->get('title');
                $maintenancerequests->content = $request->get('content');
                $maintenancerequests->author_name = $request->get('author_name');
                $maintenancerequests->author_email = $request->get('author_email');
                $maintenancerequests->department_id = $request->get('department_id');
                $maintenancerequests->sub_department_id = $request->get('sub_department_id');
                $maintenancerequests->mobile = $request->get('mobile');
                $maintenancerequests->device_id = $request->get('device_id');
                $maintenancerequests->sn = $request->get('sn');
                $maintenancerequests->model = $request->get('model');
                $maintenancerequests->date = $request->get('date');
                $maintenancerequests->room = $request->get('room');
                $maintenancerequests->deviceTypes = $request->get('deviceTypes');
                $maintenancerequests->Created_by  = Auth::user()->name;

                $isSaved = $maintenancerequests->save();

                return response()->json(['message' => $isSaved ? trans('messages.success') : "Failed to save"], $isSaved ? 201 : 400);
         } else {
             return response()->json(['message' => $validator->getMessageBag()->first()], 400);
         }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
