<?php

namespace App\Models\Maintenance;

use App\Models\Department\Department;
use App\Models\Device\Device;
use App\Models\SubDepartment\SubDepartment;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MaintenanceRequest extends Model
{
    use HasFactory;
    // public function getActivityAttribute()
    // {
    //     return $this->active ? "مفعل" : "غير مفعل";
    // }

    public function getActivityAttribute()
    {
        return $this->status ? "Todo" : "Done";
    }

     public function department()
    {
        return $this->belongsTo(Department::class,'department_id','id');
    } 

    public function subDepartment()
    {
        return $this->belongsTo(SubDepartment::class );
    }

    public function deviceType()
    {
        return $this->belongsTo(MaintenanceRequest::class );
    }
    
    public function device()
    {
        return $this->belongsTo(Device::class );
    }
}
