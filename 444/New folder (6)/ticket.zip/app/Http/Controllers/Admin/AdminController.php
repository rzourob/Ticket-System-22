<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rules\Password;
use App\Http\Traits\UserTrait;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    use UserTrait;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $admins = Admin::where('id','!=',auth('admin')->id())->get();
                $roles = Role::all();
                return response() -> view ('admin.index',['admins' => $admins,'roles' => $roles]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $admin = Admin::all();
        $roles = Role::all();
        return response()->view('admin.create',['admin'=>$admin,'roles'=>$roles]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
          //  dd($request->all());
          $validator = Validator($request->all(), [

            'name' => 'required| string|min:3| max:35',
            'email' => 'required|email',
            'password' => ['required' ,'confirmed', Password::min(3)],     

        ],[

           'name.required' =>'الرجاء ادخال أسم المستخدم',
           'email.required' => 'الرجاء ادخال البريد الاكتروني',
           'password.confirmed' => 'كلمة المرور غير متطابقة',

        ]);

        if (!$validator->fails()) {

           $admin = new Admin();
           $admin->name = $request->get('name');
           $admin->email = $request->get('email');
           $admin->password = Hash::make($request->get('password'));
           // $user->password_confirm =  Hash::make($request->get("password_confirm"));
           $admin->role_id = $request->get('role_id');
           //$user->roles_name = $request->get('roles_name');
           $admin->status = $request->get('status');
           $admin->image = $request->get('image');

           $img_name = $this->saveImg($request, $admin, 'users/$user->image');
           
           $isSaved = $admin->save();

            return response()->json(['message' => $isSaved ? trans('تم اضافة المستخدم بنجاح') : "فشل عملية اضافة المسنتخدم"], $isSaved ? 201 : 400);
        } else {
            return response()->json(['message' => $validator->getMessageBag()->first()], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $admin = Admin::find($id);
        $roles = Role::all();
        return view('admin.edit', ['admin'=>$admin ,'roles'=>$roles]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admin $admin)
    {
        //
        $validator = Validator($request->all(), [

            'name' => 'required| string|min:3| max:35',
            'email' => 'required|email',
            'password' => ['required' , Password::min(3)],

        ], [

            'name.required' => 'الرجاء ادخال أسم المستخدم',
            'email.required' => 'الرجاء ادخال البريد الاكتروني',

        ]);
        if (!$validator->fails()) {
            $admin->name = $request->get('name');
            $admin->email = $request->get('email');
            $admin->password = Hash::make($request->get('password'));
            $admin->role_id = $request->get('role_id');
            $admin->status = $request->get('status');
            $img_name = $this->saveImg($request, $admin, 'users/$user->image');
            $isSaved = $admin->save();
            return response()->json(['message' => $isSaved ? trans('تم تحديث البيانات بنجاح') : "فشل تحديث البيانات "], $isSaved ? 201 : 400);
        } else {
            return response()->json(['message' => $validator->getMessageBag()->first()], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
