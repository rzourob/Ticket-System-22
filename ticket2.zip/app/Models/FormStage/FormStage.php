<?php

namespace App\Models\FormStage;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FormStage extends Model
{
    use HasFactory;
}
