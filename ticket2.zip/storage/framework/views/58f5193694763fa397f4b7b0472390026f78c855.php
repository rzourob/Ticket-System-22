<?php echo e($department->title); ?>

<?php /**PATH C:\wamp64\www\ticket\resources\views\itdevices\data_table\title.blade.php ENDPATH**/ ?>