<?php echo e($department->title); ?>

<?php /**PATH C:\wamp64\www\ticket\resources\views\departments\data_table\title.blade.php ENDPATH**/ ?>