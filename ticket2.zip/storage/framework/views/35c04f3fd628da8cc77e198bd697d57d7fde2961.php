


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/js/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/js/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->startSection('title'); ?>
    تعديل صلاحية
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('PageTitle'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle2'); ?>
تعديل صلاحية
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <!-- form start -->
                <form id="create_form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                            
                        <div class="col-md-6">
                            <div class="col">
                                <label>أسم المسؤولية</label>
                                        <select class="form-control guards" id="guards" style="width: 100%;">
                                            <option value="">يرجى اختيار Guard<option>
                                                <option value="web" <?php if($permission->guard_name == 'web'): ?> selected <?php endif; ?>> Web<option>
                                                <option value="admin" <?php if($permission->guard_name == 'admin'): ?> selected <?php endif; ?>> Admin<option>
                                        </select>
                            </div>
                        </div> 

                        <div class="col-md-6">
                            <div class="col">
                                <label for="name">أسم الصلاحية</label>
                                    <input type="text" name="name" class="form-control" id="name" value="<?php echo e($permission->name); ?>"
                                    placeholder="Enter name">
                            </div>
                        </div> 
                    </div>
                        <br>
                    <!-- /.card-body -->
                    <div class="modal-footer">
                        <button type="button" onclick="performUpdate(<?php echo e($permission->id); ?>)" class="btn btn-primary">تعديل البيانات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/js/select2/css/select2.min.css')); ?>">
<script src="<?php echo e(asset('assets/js/select2/js/select2.full.min.js')); ?>"></script>
<script>
    //Initialize Select2 Elements
        $('.guards').select2({
        theme: 'bootstrap4'
        })
        
        function performUpdate(id){
            let data = {
                guard_name: document.getElementById('guards').value,
                name: document.getElementById('name').value,
                
            };
    
            let redirectUrl = '/admin/permissions'
            update('/admin/permissions/'+id,data,redirectUrl);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\spatie\permissions\edit.blade.php ENDPATH**/ ?>