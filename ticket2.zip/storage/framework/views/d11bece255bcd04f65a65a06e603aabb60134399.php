<div class="scrollbar side-menu-bg">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#dashboard">
                <div class="pull-left"><i class="ti-home"></i><span class="right-nav-text">لوحة التحكم</span>
                </div>
                <div class="pull-right"></i></div>
                <div class="clearfix"></div>
            </a>
            
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">نظام RMB الأدارة طلبات الصبانة </li>
        <!-- menu item Elements-->

        

        <!-- menu item calendar-->

        

        <!-- menu item todo-->
        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['View-Deives', 'View-IT', 'View-Medical', 'Index-Deives', 'Dep-Medical'])): ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-Deives')): ?>
                <li>
                    <a href="javascript:void(0);" data-toggle="collapse" data-target="#maintenances-level">
                        <div class="pull-left"><i class="ti-layers"></i><span class="right-nav-text">أدارة الأجهزة
                                وطلبات الصيانة</span></div>
                        <div class="pull-right"><i class="ti-plus"></i></div>
                        <div class="clearfix"></div>
                    </a>
                    <ul id="maintenances-level" class="collapse" data-parent="#sidebarnav">

                        <li>
                            <a href="javascript:void(0);" data-toggle="collapse"
                                data-target="#maintenances-level1">عرض أدارة الأجهزة<div class="pull-right"><i
                                        class="ti-plus"></i></div>
                                <div class="clearfix"></div>
                            </a>
                            <ul id="maintenances-level1" class="collapse">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Index-Deives')): ?>
                                    <li> <a href="<?php echo e(route('admin.viewdevice')); ?>">عرض الأجهزة </a> </li>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-Medical')): ?>
                                    <li> <a href="<?php echo e(route('admin.DevicesMedical')); ?>">عرض الأجهزة الطبية</a> </li>
                                <?php endif; ?>


                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-IT')): ?>
                                    <li> <a href="<?php echo e(route('admin.DevicesIt')); ?>">عرض أجهزة تكنولوجيا المعلومات</a>
                                    </li>
                                <?php endif; ?>

                                

                                

                                
                            </ul>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Index-R-Man.', 'View-R-Man.', 'Create-R-Man.-IT', ' Create-R-Man.-Medical'])): ?>
                            <li>
                                <a href="javascript:void(0);" data-toggle="collapse"
                                    data-target="#maintenances-level4">عرض طلبات الصيانة<div class="pull-right">
                                        <i class="ti-plus"></i>
                                    </div>
                                    <div class="clearfix"></div>
                                </a>
                                <ul id="maintenances-level4" class="collapse">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Index-R-Man.')): ?>
                                        <li> <a href="<?php echo e(route('maintenances.viewDeviceMedical')); ?>">عرض جميع الطلبات</a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create-R-Man.-Medical')): ?>
                                        <li> <a href="<?php echo e(route('admin.Request_Device_Medical')); ?>">طلبات أجهزة طبية</a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create-R-Man.-IT')): ?>
                                        <li> <a href="<?php echo e(route('admin.Request_Device_It')); ?>">طلبات أجهزة تكنولوجيا العلومات
                                            </a> </li>
                                    <?php endif; ?>

                                </ul>
                            </li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        


        <!-- menu item Ticket-->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Create-Request'])): ?>
            <li>
                
                <a href="<?php echo e(route('admin.Request_Device_Medical.create')); ?>"><i class="ti-comments"></i><span
                        class="right-nav-text">أنشاء تذكرة</span></a>
            </li>
        <?php endif; ?>


        


        <!-- menu item chat-->

        

        <!-- menu item mailbox-->

        

        <!-- menu item Charts-->
        


        <!-- menu font icon-->

        

        <!-- menu title -->


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Index-Admin', 'Index-Roles', 'Index-Permissions'])): ?>

            <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">أدارة المسخدمين و صلاحيات</li>
            <!-- menu item Widgets-->
            
            <!-- menu item Form-->

            <li>
                <a href="javascript:void(0);" data-toggle="collapse" data-target="#Form">
                    <div class="pull-left"><i class="fa fa-users" aria-hidden="true"></i><span
                            class="right-nav-text">صلاحيات المستخدمين</span></div>
                    <div class="pull-right"><i class="ti-plus"></i></div>
                    <div class="clearfix"></div>
                </a>
                <ul id="Form" class="collapse" data-parent="#sidebarnav">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Index-Permissions')): ?>
                        <li> <a href="<?php echo e(route('permissions.index')); ?>"><i class="fa fa-server"
                                    aria-hidden="true"></i>الصلاحيات</a> </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Index-Roles')): ?>
                        <li> <a href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-server"
                                    aria-hidden="true"></i>المسؤوليات</a> </li>
                    <?php endif; ?>

                    
                    <li> <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-user-plus"
                                aria-hidden="true"></i>أضافة رئيس قسم</a> </li>


                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Index-Admin')): ?>
                        <li> <a href="<?php echo e(route('admin.index')); ?>"><i class="fa fa-user-plus"
                                    aria-hidden="true"></i>
                                أضافة مسؤولين</a> </li>
                    <?php endif; ?>

                    
                    <li> <a href="<?php echo e(route('technicians.index')); ?>"><i class="fa fa-user-plus"
                                aria-hidden="true"></i>أضافة فنيين</a> </li>
                    
                </ul>
            </li>

        <?php endif; ?>
        <!-- menu item table -->

        

        
        <!-- menu item maps-->

        


        <!-- menu item Authentication-->

        

        <!-- menu item maps-->

        

        <!-- menu item timeline-->

        

        <!-- menu item Multi level-->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">الشؤون المالية والادارية</li>
        <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#multi-level">
                <div class="pull-left"><i class="ti-layers"></i><span class="right-nav-text">قسم
                        المالية</span></div>
                <div class="pull-right"><i class="ti-plus"></i></div>
                <div class="clearfix"></div>
            </a>
            <ul id="multi-level" class="collapse" data-parent="#sidebarnav">
                
                <li> <a href="<?php echo e(route('purchaseOrder.index')); ?>">عرض طلبات الشراء</a> </li>


                <li>
                    <a href="javascript:void(0);" data-toggle="collapse" data-target="#auth">أدارة
                        الموازنة العامة<div class="pull-right"></i></div></a>
                    <ul id="auth" class="collapse">
                        <li>
                            <a href="javascript:void(0);" data-toggle="collapse"
                                data-target="#login">أدارة طلبات الشراء<div class="pull-right"><i
                                        class="ti-plus"></i></div>
                                <div class="clearfix"></div>
                            </a>
                            <ul id="login" class="collapse">
                                <li>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="javascript:void(0);" data-toggle="collapse" data-target="#ha">أدارة بنود
                        الموازنة<div class="pull-right"><i class="ti-plus"></i></div>
                        <div class="clearfix"></div>
                    </a>
                    <ul id="ha" class="collapse">
                        <li> <a href="#">بنود الموازنة</a> </li>
                        <li> <a href="#">level item 2.2</a> </li>
                    </ul>
                </li>
            </ul>
        </li>

        


        

        <!-- menu item timeline-->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['View-departments', 'View-Subdepartments', 'Edit-departments', 'Delete-departments',
            'Show-departments'])): ?>
            <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">أعدادات النظام</li>
            <!-- menu item Custom pages-->
            <li>
                <a href="javascript:void(0);" data-toggle="collapse" data-target="#custom-page">
                    <div class="pull-left"><i class="fa fa-cog" aria-hidden="true"></i><span
                            class="right-nav-text">الأعدادات</span></div>
                    <div class="pull-right"><i class="ti-plus"></i></div>
                    <div class="clearfix"></div>
                </a>
                

                <ul id="custom-page" class="collapse" data-parent="#sidebarnav">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-departments')): ?>
                        <li> <a href="<?php echo e(route('departments.index')); ?>"><i class="fa fa-plus"
                                    aria-hidden="true"></i>أضافة قسم</a> </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-Subdepartments')): ?>
                        <li> <a href="<?php echo e(route('subdepartments.index')); ?>"><i class="fa fa-plus"
                                    aria-hidden="true"></i>أضافة وحدة</a> </li>
                    <?php endif; ?>
                    
                </ul>
                

            </li>
        <?php endif; ?>

    </ul>
</div><?php /**PATH C:\wamp64\www\ticket\resources\views/layouts/main-sidebar/admin-main-sidebar.blade.php ENDPATH**/ ?>