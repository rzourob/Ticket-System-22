

<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
اضافة صلاحية
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('PageTitle'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle2'); ?>
اضافة صلاحية
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-2">
        <tbody>
            <tr>
                <td>
                    <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-block btn-outline-success btn-lg"> اضافة صلاحية</a>
                </td>
            </tr>
        </tbody>
    </div>
</div>
<br>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-striped table-bordered p-0">
                      <thead>
                          <tr>
                            <th>ID</th>
                            <th>أسم الصلاحية</th>
                            <th>Guard Name</th>
                            
                            <th>تاريخ الانشاء</th>
                            
                            <th>الاجراءات</th>
                          </tr>
                      </thead>
                      <tbody>
                            
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                        <td><?php echo e($permission->id); ?></td>
                        <td><?php echo e($permission->name); ?></td>
                        <td><?php echo e($permission->guard_name); ?></td>                               
                        <td><?php echo e($permission->created_at); ?></td>
                        
                        
                        

                        <td>

                            <div class="btn-group mb-1 ">
                                <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" _msthash="3150394" _msttexthash="95992" style="direction: ltr;">الأجراءات</button>
                                <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 33px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a class="dropdown-item" href="<?php echo e(route('permissions.edit',$permission->id)); ?>">تعديل بيانات</a>
                                    <a class="dropdown-item" href="#" onclick="performDestroy(<?php echo e($permission->id); ?>,this)  " class="btn btn-danger">حذف قسم</a>
                                </div>
                            </div>

                        </td>




                          </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                
                 
                </tbody>
                      
                   </table>
                  </div>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(function () {
       $("#example1").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');   
      });
           function performDestroy(id,ref){
               confirmDestroy('/hamad/SS/permissions/'+id,ref);    
    
            }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views/spatie/permissions/index.blade.php ENDPATH**/ ?>