
<?php echo e($department->description); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\itdevices\data_table\description.blade.php ENDPATH**/ ?>