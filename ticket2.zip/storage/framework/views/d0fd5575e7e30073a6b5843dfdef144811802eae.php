<?php echo e($subdepartment->title); ?>

<?php /**PATH C:\wamp64\www\ticket\resources\views\subdepartments\data_table\title.blade.php ENDPATH**/ ?>