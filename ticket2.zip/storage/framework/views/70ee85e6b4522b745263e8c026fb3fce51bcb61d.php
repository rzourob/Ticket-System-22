
<?php echo e($device->description); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views/admin/device_Medical_Admin/data_table/description.blade.php ENDPATH**/ ?>