
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    عرض الفنيين
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
<!-- breadcrumb -->

<?php $__env->startSection('PageTitle2'); ?>
عرض الفنيين
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-2">
                <tbody>
                    <tr>
                        <td>
                         <a href="<?php echo e(route('technicians.create')); ?>" class="btn btn-block btn-outline-success btn-lg  " >أضافة مستخدم</a>
                         </td>
                    </tr>
                </tbody>

    </div>
     </div>
<br>

<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table table-striped table-bordered p-0">
                      <thead>
                          <tr>
                            <th>No.</th>
                            <th>الاسم المسخدم</th>
                            <th>البريد الاكتروني</th>
                            
                            <th>حاله المستخدم</th>
                            <th>تاريخ أضافة </th>
                            <th>تاريخ أخر تحديث </th>
                            <th>الاعدادات</th>
                          </tr>
                      </thead>
                      <tbody>
                           
                        <?php $i= 0 ; ?>
                          <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++ ; ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                          
                          <td><?php echo e($technician->name); ?></td>
                          <td><?php echo e($technician->email); ?></td>
                          
                          <td>
                                  <?php if($technician->status == 'مفعل'): ?>
                                      <span class="badge ">
                                          <div class="dot-label bg-success ml-1"></div><?php echo e($technician->status); ?>

                                      </span>
                                  <?php else: ?>
                                      <span class="badge ">
                                          <div class="dot-label bg-danger ml-1"></div><?php echo e($technician->status); ?>

                                      </span>
                                  <?php endif; ?>
                              </td>

                          <td><?php echo e($technician->created_at); ?></td>
                          <td><?php echo e($technician->updated_at); ?></td>
                          <td>
                              <div class="btn-group">
                                  <a href="<?php echo e(route('technicians.edit',$technician->id)); ?>" class="btn btn-info">
                                      <i class="fa fa-edit"></i>
                                  </a>

                                  <a href="#" onclick="performDestroy(<?php echo e($technician->id); ?>,this)  " class="btn btn-danger">
                                      <i class="fa fa-trash"></i>
                                  </a>
                                  </a>            
                              </div>
                          </td>
                     
                          </tr> 
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
                   </table>
                  </div>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
           function performDestroy(id,ref){
               confirmDestroy('/admin/technicians/'+id,ref);    
    
            }
            
    
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\technician\index.blade.php ENDPATH**/ ?>