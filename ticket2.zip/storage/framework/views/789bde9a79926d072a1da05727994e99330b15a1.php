
<?php echo e($maintenanceRequest->content); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\users\device_Medical_User\data_table\content.blade.php ENDPATH**/ ?>