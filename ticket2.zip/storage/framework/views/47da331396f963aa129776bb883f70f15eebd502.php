<?php $__env->startComponent('mail::message'); ?>
# RMB Ticket System

Welcom in RMB Ticket System

<?php $__env->startComponent('mail::panel'); ?>
يرجي فحص النظام يوجد لديك تذاكر بنتظار الرد عليها
<?php echo $__env->renderComponent(); ?>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\ticket\resources\views\emails\Ticket.blade.php ENDPATH**/ ?>