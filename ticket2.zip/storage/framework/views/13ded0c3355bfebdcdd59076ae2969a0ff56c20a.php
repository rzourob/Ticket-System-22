
<?php echo e($maintenanceRequest->content); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\view_Request_medical\data_table\content.blade.php ENDPATH**/ ?>