




<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    empty
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    empty
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
           
            <h3 class="card-title"> الصلاحيات</h3>

            
          
            <div class="card-body table-responsive p-1">
                    <table  id="example1" class="table table-bordered table table-striped " style="text-align: center">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Guard</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                  <td><?php echo e($permission->id); ?></td>
                  <td><?php echo e($permission->name); ?></td>
                  <td><span class="badge bg-success"><?php echo e($permission->guard_name); ?></span></td>
                  <td>
                    <div class="icheck-primary d-inline">
                      <input type="checkbox" id="permission_<?php echo e($permission->id); ?>"
                        onchange="storeRolePermission(<?php echo e($roleId); ?>,<?php echo e($permission->id); ?>)" <?php if($permission->active): ?> checked
                      <?php endif; ?>>
                      <label for="permission_<?php echo e($permission->id); ?>">
                      </label>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
                <!-- /.card-body -->            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>

$(function () {
   $("#example1").DataTable({
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    
  });

       function storeRolePermission(roleId, permissionId){
    let data = {
      permission_id: permissionId,
    };
    
    store('/admin/role/'+roleId+'/permissions',data);
  }
     
        

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\spatie\role_user\role-permissions.blade.php ENDPATH**/ ?>