<?php echo e($patient->first_name); ?> 
<?php echo e($patient->father_name); ?> 
<?php echo e($patient->grandfather_name); ?> 
<?php echo e($patient->family_name); ?>




<?php echo e($patient->fullName); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\subdepartments\data_table\fullName.blade.php ENDPATH**/ ?>