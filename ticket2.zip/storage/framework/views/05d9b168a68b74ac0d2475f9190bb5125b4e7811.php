

<?php if($department ->active): ?>
<span class="badge bg-success"><?php echo e($department->activity); ?></span>
<?php else: ?>                           
<span class="badge bg-danger"><?php echo e($department->activity); ?></span>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\ticket\resources\views\itdevices\data_table\active.blade.php ENDPATH**/ ?>