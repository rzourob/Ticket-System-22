
<?php $__env->startComponent('mail::message'); ?>
# RMB Ticket System

Welcom in RMB Ticket System .
<?php $__env->startComponent('mail::panel'); ?>
To Login to your RMB Ticket system click on the below button
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:8000/login/user']); ?>
Control Panel
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\ticket\resources\views\emails\welcom.blade.php ENDPATH**/ ?>