


<?php if($subdepartment ->active): ?>
<span class="btn btn-success"><?php echo e($subdepartment->activity); ?></span>
<?php else: ?>                           
<span class="btn btn-danger"><?php echo e($subdepartment->activity); ?></span>
<?php endif; ?><?php /**PATH C:\wamp64\www\ticket\resources\views\subdepartments\data_table\active.blade.php ENDPATH**/ ?>