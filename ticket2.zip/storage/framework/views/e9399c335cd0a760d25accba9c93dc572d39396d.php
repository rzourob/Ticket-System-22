
<?php echo e($department->description); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\departments\data_table\description.blade.php ENDPATH**/ ?>