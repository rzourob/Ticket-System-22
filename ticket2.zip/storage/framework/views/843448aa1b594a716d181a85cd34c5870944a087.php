<div class="btn-group mb-1">
	<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" _msthash="3150394" _msttexthash="95992" style="direction: ltr;">الأجراءات</button>
	<div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 33px, 0px); top: 0px; left: 0px; will-change: transform;">
		<a class="dropdown-item" href="<?php echo e(route('user.Request_IT.edit',$id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
			تعديل بيانات</a>

			<a class="dropdown-item" href="<?php echo e(route('user.Details_IT.show',$id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i>
				عرض تفاصيل التذكرة</a>


		<a class="dropdown-item" href="<?php echo e(route('user.cmmentShow',$id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i>
			أضافة رد</a>

		
	</div>
</div>




<?php /**PATH C:\wamp64\www\ticket\resources\views/users/request_maintenances_It/data_table/actions.blade.php ENDPATH**/ ?>