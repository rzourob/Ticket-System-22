<?php echo e($maintenancerequest->tiket_no); ?>




<?php /**PATH C:\wamp64\www\ticket\resources\views\users\device_It_User\data_table\tiket_no.blade.php ENDPATH**/ ?>