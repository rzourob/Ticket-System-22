<title><?php echo $__env->yieldContent("title"); ?></title>


<!-- Favicon -->
<link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" />

<!-- Font -->
<link  rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900">

<!-- css -->
<link rel="stylesheet" type="text/css" href="<?php echo e(URL :: asset('assets/css/style.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(URL :: asset('assets/css/rtl.css')); ?>" />



<?php echo $__env->yieldContent('css'); ?>
 <?php /**PATH C:\wamp64\www\ticket\resources\views/layouts/head.blade.php ENDPATH**/ ?>