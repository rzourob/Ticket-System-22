





<span >

    <?php if($maintenancerequest->status == "Todo"): ?>
    <span class=" btn btn-warning">جاري العمل عليها</span>
    
    <?php elseif($maintenancerequest->status == "Done"): ?>
    <span class=" btn btn-primary">انتهت</span>

    
    <?php endif; ?>
</span><?php /**PATH C:\wamp64\www\ticket\resources\views\maintenances\data_table\active.blade.php ENDPATH**/ ?>