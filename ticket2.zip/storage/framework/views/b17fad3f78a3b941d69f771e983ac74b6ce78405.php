
<?php echo e($device->description); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\devices\data_table\description.blade.php ENDPATH**/ ?>