





<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    empty
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    empty
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                   <div class="modal-header">
                <h5 style="font-family: 'Cairo', sans-serif;" class="modal-title" id="exampleModalLabel">
                    أضافة مستخدم جديد
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <br>

                   <form id="create_form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                                
                                <div class="col-md-6">
                                    <div class="col">
                                        <label for="name" class="mr-sm-2">أسم المستخدم</label>
                                        <input type="text" name="name" class="form-control" id="name" value="<?php echo e($user->name); ?>"
                                        placeholder="يرجى أدخال اسم المستخدم">
                                    </div>
                                </div> 

                                <div class="col-md-6">
                                    <div class="col">
                                         <label for="email" class="mr-sm-2">البريد الاكتروني</label>
                                         <input type="email" name="email" class="form-control" id="email" value="<?php echo e($user->email); ?>"
                                           placeholder="يرجي أدخال كلمة المرور">
                                    </div>
                                </div> 
                    
                        </div>
<br>
                        <div class="row">
                                <div class="col-md-6">
                                    <div class="col">
                                         <label for="password" class="mr-sm-2">الرقم السري</label>
                                         <input type="password" name="password" class="form-control" id="password" autocomplete="new-password" value="<?php echo e($user->password); ?>"
                                           placeholder="يرجي ادخال الرقم السري">
                                    </div>
                                </div> 

                                

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">حالة المستخدم</label>
                                            <select class="form-control status" id="status" style="width: 100%;">
                                               <option value="">أختار حالة المستخدم</option>
                                                     <option value="مفعل" <?php echo e($user->status == "مفعل"  ? 'selected' : ''); ?>>مفعل</option>
                                                     <option value="غير مفعل" <?php echo e($user->status == "غير مفعل"  ? 'selected' : ''); ?>>غير مفعل</option>
                                            </select>
                                    </div>
                                </div>

                                

                                
                        </div>

                        <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">نوع المستخدم</label>
                                            <select class="form-control roles" multiple="multiple" id="roles" id="roles" style="width: 100%;" multiple="">
                                               <option value="">أختار نوع المستخدم</option>
                                               <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                </div>
                        
                        <br>
         



                            
                        </div>
                        <!-- /.card-body -->

                            <div class="modal-footer">
                                <button type="button" onclick="performUpdate(<?php echo e($user->id); ?>)" class="btn btn-primary">أنشاء مستخدم</button>
                            </div>
                    </form> 
                      
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script>

$('.select2bs4').select2({
      theme: 'bootstrap4'
    });

    $('.roles').select2({
      theme: 'bootstrap4'
    });

    $('.status').select2({
        theme: 'bootstrap4'
    });

$(function () {
   $("#example1").DataTable({
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    
  });

        function performUpdate(id){
        let data = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            password: document.getElementById('password').value,
            //role_id: document.getElementById('roles').value,
            status: document.getElementById('status').value,
        };

        //store('/ar/users',data);

        let redirectUrl ='/hamad/SS/users'
        update('/hamad/SS/users'+id,data);
    }
        

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\technician\edit1.blade.php ENDPATH**/ ?>