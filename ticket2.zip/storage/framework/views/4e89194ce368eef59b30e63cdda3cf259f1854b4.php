<div class="btn-group mb-1">
	<button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" _msthash="3150394" _msttexthash="95992" style="direction: ltr;">الأجراءات</button>
	<div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 33px, 0px); top: 0px; left: 0px; will-change: transform;">
		<a class="dropdown-item" href="<?php echo e(route('admin.Request_Device_It.edit',$id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
			تعديل بيانات</a>

			<a class="dropdown-item" href="<?php echo e(route('admin.Request_Device_It.show',$id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i>
				عرض تفاصيل التذكرة</a>


		<a class="dropdown-item" href="<?php echo e(route('cmmentShow.data',$id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i>
			أضافة رد</a>

		<a class="dropdown-item" href="#" onclick="performDestroy(<?php echo e($id); ?>, this)  " class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i>
			حذف التذكرة</a>
	</div>
</div>




<?php /**PATH C:\wamp64\www\ticket\resources\views\admin\request_maintenances_It\data_table\actions.blade.php ENDPATH**/ ?>