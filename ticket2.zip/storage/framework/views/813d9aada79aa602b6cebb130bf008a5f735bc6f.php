



    
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e(trans('role_trans.view_role')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('role_trans.view_role')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
            
            
    <div class="col-md-3">

        <div class="container-fluid">

            <tbody>

                <tr>

                    <td>
                            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-block btn-outline-success btn-lg"><?php echo e(trans('role_trans.add_role')); ?></a>
                    </td>


                </tr>
            </tbody>
        </div>

    </div>

<br>

<!-- /.card-header -->
                <div class="card-body table-responsive p-1">
                    <table  id="example1" class="table table-bordered table table-striped " style="text-align: center">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th><?php echo e(trans('role_trans.name')); ?></th>
                                <th><?php echo e(trans('role_trans.guard_name')); ?></th>
                                <th><?php echo e(trans('role_trans.permissions')); ?></th> 
                                <th><?php echo e(trans('role_trans.date_created')); ?></th>
                                
                                <th><?php echo e(trans('role_trans.action')); ?></th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                <td><?php echo e($role->id); ?></td>
                                <td><?php echo e($role->name); ?></td>
                                <td><?php echo e($role->guard_name); ?></td>
                                <td><a href="<?php echo e(route('role.permissions.index',$role->id)); ?>"
                                    class="btn btn-info"><?php echo e($role->permissions_count); ?>Permission/s</a></td>                                 
                                <td><?php echo e($role->created_at); ?></td>
                                
                                
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('roles.edit',$role->id)); ?>" class="btn btn-info">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        
                                         <a href="#" onclick="performDestroy(<?php echo e($role->id); ?>,this)  " class="btn btn-danger">
                                            <i class="fa fa-trash"></i>
                                         </a>
                                       
                                    </div>
                                </td>




                                  </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        
                         
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->            </div>
        </div>
        </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>

$(function () {
   $("#example1").DataTable({
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    
  });

       function performDestroy(id,ref){
            confirmDestroy(/'ar/roles/'+id,ref);    
        }    

     
        

</script>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\spatie\roles\index1.blade.php ENDPATH**/ ?>