<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Delete-Deives', 'Edit-Deives', 'Show-Deives', 'Movements-Deives'])): ?>
    <div class="btn-group mb-1">

        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false" _msthash="3150394" _msttexthash="95992" style="direction: ltr;">الأجراءات</button>
        <div class="dropdown-menu" x-placement="bottom-start"
            style="position: absolute; transform: translate3d(0px, 33px, 0px); top: 0px; left: 0px; will-change: transform;">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit-Deives')): ?>
                
            <?php endif; ?>

            

            


            

        </div>
    </div>
<?php endif; ?>


<script>
    function performDestroy(id, ref) {
        confirmDestroy('/admin/devices/' + id, ref);

    }
</script>
<?php /**PATH C:\wamp64\www\ticket\resources\views\admin\data_table\actions.blade.php ENDPATH**/ ?>