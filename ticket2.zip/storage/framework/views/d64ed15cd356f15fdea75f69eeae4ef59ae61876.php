

<?php if($device ->active): ?>
<span class="btn btn-success"><?php echo e($device->activity); ?></span>
<?php else: ?>                           
<span class="btn btn-danger"><?php echo e($device->activity); ?></span>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\ticket\resources\views\purchaseOrder\data_table\active.blade.php ENDPATH**/ ?>