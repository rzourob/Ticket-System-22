<?php

namespace App\Models\CurrentStage;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CurrentStage extends Model
{
    use HasFactory;
}
