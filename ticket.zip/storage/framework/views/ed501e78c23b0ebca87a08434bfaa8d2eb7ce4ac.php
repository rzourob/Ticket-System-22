<?php echo e($subdepartment->department->title); ?>

<?php /**PATH C:\wamp64\www\ticket\resources\views\subdepartments\data_table\department.blade.php ENDPATH**/ ?>