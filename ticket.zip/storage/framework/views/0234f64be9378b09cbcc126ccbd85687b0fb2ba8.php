<?php echo e($device->title); ?>

<?php /**PATH C:\wamp64\www\ticket\resources\views\admin\data_table\title.blade.php ENDPATH**/ ?>