


                                  <td>
                                    <span class="btn btn-info">

                                        <?php if($device->deviceTypes == 1): ?>
                                         جهاز طبي
                                        <?php elseif($device->deviceTypes == 2): ?>
                                        جهاز تكنولوجيا المعلومات

                                        <?php elseif($device->deviceTypes == 3): ?>
                                        جهاز هندسة وصيانة
                                        
                                        <?php endif; ?>
                                    </span>
                         
                                  </td>

                                  
<?php /**PATH C:\wamp64\www\ticket\resources\views\users\device_Medical_User\data_table\deviceTypes.blade.php ENDPATH**/ ?>