<ul class="list-inline">
    <li class="media d-block d-sm-flex">
        <img alt="" class="main-img-user avatar-lg mg-sm-l-10 mg-b-10 mg-sm-b-0  img-fluid mr-15 avatar-small" height="430" with="450"
        src="<?php echo e(Storage::url('public/devices/' . $device->image ?? '')); ?>">
    </li>
</ul>



<?php /**PATH C:\wamp64\www\ticket\resources\views/users/device_Medical_User/data_table/image.blade.php ENDPATH**/ ?>