





<span >

    <?php if($comment->new_status == "Todo"): ?>
    <span class=" btn btn-warning">جاري العمل عليها</span>
    
    <?php elseif($comment->new_status == "Done"): ?>
    <span class=" btn btn-primary">انتهت</span>

    
    <?php endif; ?>
</span><?php /**PATH C:\wamp64\www\ticket\resources\views\admin\request_maintenances_Medical\data_table\new_status.blade.php ENDPATH**/ ?>