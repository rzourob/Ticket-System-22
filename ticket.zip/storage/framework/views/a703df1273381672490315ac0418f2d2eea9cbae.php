
<?php echo e($subdepartment->description); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\subdepartments\data_table\description.blade.php ENDPATH**/ ?>