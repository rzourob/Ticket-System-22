
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    تفاصيل الجها
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle2'); ?>
    تفاصيل الجهاز
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->

<div class="row">
    <div class="col-md-12 mb-30">

        <div>

            <div class="float-start">
                <h4 class="pb-3" style="font-family: 'Cairo', sans-serif">تفاصيل التذكرة</h4>
            </div>

            <div class="clearfix"></div>
        </div>

        <div class="card mt-3">
            <h5 class="card-header">
                <?php if($maintenancerequests->status === 'Todo'): ?>
                    <?php echo e($maintenancerequests->title); ?>

                <?php else: ?>
                    
                    <?php echo e($maintenancerequests->title); ?>

                <?php endif; ?>

                <span class="badge rounded-pill bg-warning text-dark">
                     <?php echo e($maintenancerequests->Created_by); ?>

                </span> 

                <span class="badge rounded-pill bg-warning text-dark">
                    <?php echo e($maintenancerequests->created_at->diffForHumans()); ?>

                </span>
            </h5>

            <div class="card-body">
                <div class="card-text">
                    <div class="float-start">
                        <?php if($maintenancerequests->status === 'Todo'): ?>
                            <?php echo e($maintenancerequests->content); ?>


                            
                        <?php else: ?>
                            
                            <?php echo e($maintenancerequests->content); ?>


                            
                        <?php endif; ?>
                        <br>

                        <?php if($maintenancerequests->status === 'Todo'): ?>
                            <span class="badge rounded-pill bg-info text-dark">
                                Todo
                            </span>
                        <?php else: ?>
                            <span class="badge rounded-pill bg-success text-white">
                                Done
                            </span>
                        <?php endif; ?>


                        <small>أخرتحديث - <?php echo e($maintenancerequests->updated_at->diffForHumans()); ?> </small>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mt-3">
                <h5 class="card-header">
                    <?php if($comment->new_status === 'Todo'): ?>
                        <?php echo e($comment->maintenancerequest->title); ?>

                    <?php else: ?>
                        
                        <?php echo e($comment->maintenancerequest->title); ?>

                    <?php endif; ?>

                    <span class="badge rounded-pill bg-warning text-dark">
                        <?php echo e($comment->Created_by); ?>

                    </span>

                    <span>
                        <?php if($comment->new_status === 'Todo'): ?>
                            <span class="badge rounded-pill bg-info text-dark">
                                Todo
                            </span>
                        <?php else: ?>
                            <span class="badge rounded-pill bg-success text-white">
                                Done
                            </span>
                        <?php endif; ?>
                    </span>
                </h5>

                <div class="card-body">
                    <div class="card-text">
                        <div class="float-start">
                            <?php if($comment->new_status === 'Todo'): ?>
                                <?php echo e($comment->body); ?>

                            <?php else: ?>
                                
                                <?php echo e($comment->body); ?>

                            <?php endif; ?>

                        </div>
                        <br>


                        

                        <small>أخرتحديث - <?php echo e($comment->updated_at->diffForHumans()); ?> </small>



    

                        <div class="float-end ">
                            <a href="#" class="btn btn-success left ">
                                تعديل الرد</i>
                            </a>


                            <a href="#" onclick="performDestroy(<?php echo e($comment->id); ?>,this)  "
                                class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i>
                                حذف الرد</a>

                            

                        

                     


                        <div class="clearfix"></div>
                    </div>
                </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>



<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script>
    function performDestroy(id, ref) {
        confirmDestroy('/Request/maintenances/' + id, ref);

    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\admin\request_maintenances_It\show.blade.php ENDPATH**/ ?>