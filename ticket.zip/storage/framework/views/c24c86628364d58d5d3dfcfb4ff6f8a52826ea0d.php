





    
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e(trans('permissions_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('permissions_trans.title_page')); ?>

<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
            
            <div class="col-md-3">

        <div class="container-fluid">
            <tbody>
                <tr>
                    <td>
                            <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-block btn-outline-success btn-lg  " ><?php echo e(trans('permissions_trans.add_permissions')); ?></a>
                    </td>
                </tr>
            </tbody>
        </div>

    </div>

     <br>                <!-- /.card-header -->
                <div class="card-body table-responsive p-1">
                    <table  id="example1" class="table table-bordered table table-striped " style="text-align: center">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th><?php echo e(trans('permissions_trans.name')); ?></th>
                                <th><?php echo e(trans('permissions_trans.guard_name')); ?></th>
                                <th><?php echo e(trans('permissions_trans.date_created')); ?></th>
                                
                                <th><?php echo e(trans('permissions_trans.action')); ?></th>                                
                            </tr>
                        </thead>
                        <tbody>                            
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                <td><?php echo e($permission->id); ?></td>
                                <td><?php echo e($permission->name); ?></td>
                                <td><?php echo e($permission->guard_name); ?></td>                               
                                <td><?php echo e($permission->created_at); ?></td>
                                
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('permissions.edit',$permission->id)); ?>" class="btn btn-info">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                        
                                         <a href="#" onclick="performDestroy(<?php echo e($permission->id); ?>,this)  " class="btn btn-danger">
                                            <i class="fa fa-trash"></i>
                                         </a>
                                    </div>
                                </td>
                                  </tr> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body --> 
            </div>               
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(function () {
   $("#example1").DataTable({
    "responsive": true, "lengthChange": false, "autoWidth": false,
    "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');   
  });
       function performDestroy(id,ref){
           confirmDestroy('/hamad/SS/permissions/'+id,ref);    

        }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\spatie\permissions\index1.blade.php ENDPATH**/ ?>