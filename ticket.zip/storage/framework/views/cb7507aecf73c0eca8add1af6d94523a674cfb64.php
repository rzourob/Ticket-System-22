<?php echo e($maintenancerequest->title); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\view_Request_medical\data_table\title.blade.php ENDPATH**/ ?>