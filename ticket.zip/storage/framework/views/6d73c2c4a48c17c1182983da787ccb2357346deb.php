


                                  <td>
                                    <span class="btn btn-info">

                                        <?php if($maintenancerequest->deviceTypes == 1): ?>
                                         جهاز طبي
                                        <?php elseif($maintenancerequest->deviceTypes == 2): ?>
                                        جهاز تكنولوجيا المعلومات

                                        <?php elseif($maintenancerequest->deviceTypes == 3): ?>
                                        جهاز هندسة وصيانة
                                        
                                        <?php endif; ?>
                                    </span>
                         
                                  </td><?php /**PATH C:\wamp64\www\ticket\resources\views/users/request_maintenances_It/data_table/deviceTypes.blade.php ENDPATH**/ ?>