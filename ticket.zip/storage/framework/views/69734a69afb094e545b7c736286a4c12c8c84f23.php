


<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    صلاحيات المسؤولية
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle2'); ?>
صلاحيات المسؤولية
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
صلاحيات المسؤولية
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
  <div class="col-md-12 mb-30">
      <div class="card card-statistics h-100">
          <div class="card-body">
              <div class="table-responsive">
                  <table id="datatable" class="table table-striped table-bordered p-0">
                    <thead>
                        <tr>
                          <th>ID</th>
                          <th>Name</th>
                          <th>Guard</th>
                          <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
      
                        <td><?php echo e($permission->id); ?></td>
                        <td><?php echo e($permission->name); ?></td>
                        <td><span class="btn btn-info"><?php echo e($permission->guard_name); ?></span></td>
                        <td>
                          

                          <div class="checkbox checbox-switch switch-success">
                            <label for="permission_<?php echo e($permission->id); ?>">
                                <input type="checkbox" id="permission_<?php echo e($permission->id); ?>" onchange="storeRolePermission(<?php echo e($role->id); ?>,<?php echo e($permission->id); ?>)" <?php if($permission->active): ?> checked
                                <?php endif; ?>>
                                <span></span>
                            </label>
                        </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                 </table>
                </div>
          </div>
      </div>
  </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>

  
         function storeRolePermission(roleId, permissionId){
      let data = {
        permission_id: permissionId,
      };
      
      store('/admin/role/'+roleId+'/permissions',data);
    }
       
          
  
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\spatie\roles\role-permissions.blade.php ENDPATH**/ ?>