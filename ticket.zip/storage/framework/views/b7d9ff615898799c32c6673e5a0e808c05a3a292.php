<?php echo e($maintenancerequest->title); ?>




<?php /**PATH C:\wamp64\www\ticket\resources\views\users\device_Medical_User\data_table\subject.blade.php ENDPATH**/ ?>