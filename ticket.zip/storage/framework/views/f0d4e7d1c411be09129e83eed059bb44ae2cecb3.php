<?php echo e($maintenancerequest->title); ?>


<?php echo e($maintenancerequest->tiket_no); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\admin\request_maintenances_Medical\data_table\title.blade.php ENDPATH**/ ?>