<?php echo e($maintenancerequest->tiket_no); ?>




<?php /**PATH C:\wamp64\www\ticket\resources\views\users\data_table\tiket_no.blade.php ENDPATH**/ ?>