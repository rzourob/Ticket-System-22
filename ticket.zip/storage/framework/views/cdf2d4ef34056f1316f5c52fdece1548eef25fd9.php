<div class="scrollbar side-menu-bg">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#dashboard">
                <div class="pull-left"><i class="ti-home"></i><span class="right-nav-text">لوحة التحكم</span>
                </div>
                <div class="pull-right"></i></div>
                <div class="clearfix"></div>
            </a>
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title">نظام RMB الأدارة طلبات الصبانة </li>
        <!-- menu item Elements-->


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['View-Deives', 'View-IT', 'View-Medical', 'Index-Deives', 'Dep-Medical'])): ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-Deives')): ?>
                <li>
                    <a href="javascript:void(0);" data-toggle="collapse" data-target="#maintenances-level">
                        <div class="pull-left"><i class="ti-layers"></i><span class="right-nav-text">أدارة الأجهزة
                                وطلبات الصيانة</span></div>
                        <div class="pull-right"><i class="ti-plus"></i></div>
                        <div class="clearfix"></div>
                    </a>
                    <ul id="maintenances-level" class="collapse" data-parent="#sidebarnav">

                        <li>
                            <a href="javascript:void(0);" data-toggle="collapse"
                                data-target="#maintenances-level1">عرض أدارة الأجهزة<div class="pull-right"><i
                                        class="ti-plus"></i></div>
                                <div class="clearfix"></div>
                            </a>
                            <ul id="maintenances-level1" class="collapse">

                                

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-Medical')): ?>
                                    <li> <a href="<?php echo e(route('user.DevicesMedical')); ?>">عرض الأجهزة الطبية</a> </li>
                                <?php endif; ?>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('View-IT')): ?>
                                    
                                    <li> <a href="<?php echo e(route('user.DevicesIt')); ?>">عرض أجهزة تكنولوجيا المعلومات</a> </li>

                                <?php endif; ?>


                                
                            </ul>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Index-R-Man.', 'View-R-Man.', 'Create-R-Man.-IT', ' Create-R-Man.-Medical'])): ?>
                            <li>
                                <a href="javascript:void(0);" data-toggle="collapse"
                                    data-target="#maintenances-level4">عرض طلبات الصيانة<div class="pull-right">
                                        <i class="ti-plus"></i>
                                    </div>
                                    <div class="clearfix"></div>
                                </a>
                                <ul id="maintenances-level4" class="collapse">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Index-R-Man.')): ?>
                                        <li> <a href="#">عرض جميع الطلبات</a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create-R-Man.-Medical')): ?>
                                        <li> <a href="#">طلبات أجهزة طبية</a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Create-R-Man.-IT')): ?>
                                        <li> <a href="<?php echo e(route('user.View_Request_IT')); ?>">طلبات أجهزة تكنولوجيا العلومات
                                            </a> </li>
                                    <?php endif; ?>

                                </ul>
                            </li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>
        <?php endif; ?>

        


        <!-- menu item Ticket-->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Create-Request'])): ?>
            <li>
                
                <a href="<?php echo e(route('user.Device_It.create')); ?>"><i class="ti-comments"></i><span
                        class="right-nav-text">أنشاء تذكرة</span></a>
            </li>
        <?php endif; ?>

        

  



      

    </ul>
</div><?php /**PATH C:\wamp64\www\ticket\resources\views/layouts/main-sidebar/user-main-sidebar.blade.php ENDPATH**/ ?>