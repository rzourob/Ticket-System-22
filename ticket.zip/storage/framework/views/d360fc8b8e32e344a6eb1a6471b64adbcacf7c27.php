
<?php $__env->startSection('css'); ?>

<?php $__env->startSection('title'); ?>
    تفاصيل الجها
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle2'); ?>
    تفاصيل الجهاز
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->

<div class="row">   
    <div class="col-md-12 mb-30">     
      <div class="card card-statistics h-100"> 
        <div class="card-body">    
          <h5 class="card-title text-center">معلومات حول الجهاز</h5>
           <!-- -->
           <div class="row invoice-info text-left">
            <div class="col-sm-4 ">
            </div>
            <div class="col-sm-5">
            </div>
            <div class="col-sm-3 ">

              
              <img class="img-circle img-bordered-sm" height="200" with="80"   src="<?php echo e(Storage::url('public/devices/' . $devices->image ?? '')); ?>" alt="User profile picture">
            </div>
        </div>
        <!-- -->
          

         
          <div class="row invoice-info">

            <div class="col-sm-4 invoice-col">
              <address>
                <strong></strong><br>
                <h5><strong>بار كود الجهاز  : <?php echo e($devices->codeDevices); ?></strong></h5><br>
                <h5><strong>اسم الجهاز : <?php echo e($devices->title); ?></strong></h5><br>
                
              </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
              <address>
                <strong></strong><br>
                <h5><strong>نوع الجهاز  : 
                    <td>
                                    <span >
                                        <?php if($devices->deviceTypes == "1"): ?>
                                        جهاز طبي
                                        <?php elseif($devices->deviceTypes == "2"): ?>
                                        تكنولوجيا المعلومات
                
                                        <?php elseif($devices->deviceTypes == "3"): ?>
                                        هندسة وصيانة
                
                                       <?php elseif($devices->deviceTypes == "divorced"): ?>
                                        مطلق
                                        <?php endif; ?>
                                    </span>
                                </td> 
                    </strong></h5><br>
                <h5><strong>الشركة المصنعة : <?php echo e($devices->manufacturer); ?></strong></h5><br>
              </address>
            </div>
            <!-- /.col -->
            <div class="col-sm-4 invoice-col">
                <strong></strong><br>
              <h5><strong>موديل الجهاز  : <?php echo e($devices->model); ?> </strong></h5><br>
              <h5><strong>SN:  <?php echo e($devices->sn); ?></strong></h5><br>
              <br>
            </div>

            <div class="col-sm-4 invoice-col">
              <h5><strong> الشركة الموردة  :  <?php echo e($devices->supplier); ?></strong></h5><br>
              
              <br>
            </div>

            <div class="col-sm-4 invoice-col">

              <h5><strong> فترة الضمان  : <?php echo e($devices->warranty); ?></strong></h5><br>
              <br>

            </div>


            <div class="col-sm-12 invoice-col">
             
              <h5><strong>ملاحظات: </strong></h5><br>
              <h5><strong> </strong></h5><br>

              <br>
              

              
                <div class="row no-print col-md-12 text-center table-responsive p-20">
                  <div class="col-12">
                    
                    


                    <a class="btn btn-primary btn-outline backForm btn-lg " href="#"
                        type="button">العودة الى قائمة الرئيسية
                    </a> 
                  </div>
                </div>

            </div>

            <!-- /.col -->
          </div> 
        </div>
      </div>   
    </div>
     
</div>

<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\devices\show1.blade.php ENDPATH**/ ?>