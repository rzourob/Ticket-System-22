<?php echo e($device->title); ?>

<?php /**PATH C:\wamp64\www\ticket\resources\views\admin\device_Medical_Admin\data_table\titleRequest.blade.php ENDPATH**/ ?>