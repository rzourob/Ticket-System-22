
<?php if($department ->active): ?>
<span class="btn btn-success"><?php echo e($department->activity); ?></span>
<?php else: ?>                           
<span class="btn btn-danger"><?php echo e($department->activity); ?></span>
<?php endif; ?><?php /**PATH C:\wamp64\www\ticket\resources\views\departments\data_table\active.blade.php ENDPATH**/ ?>