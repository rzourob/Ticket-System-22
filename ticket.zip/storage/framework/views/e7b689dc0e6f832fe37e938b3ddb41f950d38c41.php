

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/js/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/js/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->startSection('title'); ?>
    أنشاء قسم فرعي
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('PageTitle'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle2'); ?>
أنشاء قسم فرعي
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <!-- form start -->

                <form id="create_form">
                    <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="col">
                                        <label>القسم الرئيسي</label>
                                        <select class="form-control departments" id="departments" style="width: 100%;">
                                            <option value="">أختار القسم</option>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>" <?php echo e($department->id == $subdepartments->department_id ? 'selected' : ''); ?>><?php echo e($department->title); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>                 
                            </div>
                    <br>
                            <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="col">
                                            <label for="title" class="mr-sm-2">أسم القسم</label>
                                            <input type="text" name="title" class="form-control" id="title" value="<?php echo e($subdepartments->title); ?>"
                                            placeholder="ادخل اسم القسم باللغة العربية">
                                        </div>
                                    </div> 
                                    

                                    <div class="col-md-6">
                                        <div class="col">
                                            <label for="title_en" class="mr-sm-2">أسم القسم</label>
                                            <input type="text" name="title_en" class="form-control" id="title_en" 
                                            placeholder="ادخل اسم المدينة القسم الانجيليزية">
                                        </div>
                                    </div> 
                            
                            </div>

                    <br>

                            <div class="row">
                                    <div class="col-md-12">
                                        <div class="col">
                                            <label for="description">وصف القسم</label>
                                            <textarea class="form-control" style="resize: none;"  type="text" id="description" name="description" rows="4"
                                            placeholder="وصف القسم" cols="50"><?php echo e($subdepartments->description); ?></textarea>
                                        </div>
                                    </div>
                            </div>

                    <br>

                            <div class="form-check">
                                <input type="checkbox" name="active"class="form-check-input" id="active"
                                <?php if($subdepartments->active): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="active">تفعيل</label>
                            </div>
                    </div>
                    <!-- /.card-body -->

                            <div class="modal-footer">
                                <button type="button" onclick="performUpdate(<?php echo e($subdepartments->id); ?>)" class="btn btn-primary">تعديل البيانات</button>
                            </div>

                </form> 
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/js/select2/css/select2.min.css')); ?>">
<script src="<?php echo e(asset('assets/js/select2/js/select2.full.min.js')); ?>"></script>
    
<script>
         
    $('.departments').select2({
   theme: 'bootstrap4'
   });

function performUpdate(id){
   let data = {
       department_id: document.getElementById('departments').value,
       title: document.getElementById('title').value,             
       title_en: document.getElementById('title_en').value,
       description: document.getElementById('description').value,
       active: document.getElementById('active').checked,
   };
       
   let redirectUrl = '/admin/subdepartments'
        update('/admin/subdepartments/'+id,data,redirectUrl);}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\subdepartments\edit.blade.php ENDPATH**/ ?>