
<?php echo e($device->description); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\users\device_Medical_User\data_table\description.blade.php ENDPATH**/ ?>