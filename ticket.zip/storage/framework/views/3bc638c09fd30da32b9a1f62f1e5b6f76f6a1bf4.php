 
<?php /**PATH C:\wamp64\www\ticket\resources\views\purchaseOrder\javascript\sershNo.blade.php ENDPATH**/ ?>