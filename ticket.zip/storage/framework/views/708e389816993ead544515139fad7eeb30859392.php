
<?php echo e($maintenanceRequest->content); ?>


<?php /**PATH C:\wamp64\www\ticket\resources\views\technician\data_table\content.blade.php ENDPATH**/ ?>