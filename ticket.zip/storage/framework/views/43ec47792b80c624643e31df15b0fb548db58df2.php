<?php echo e($maintenancerequest->title); ?>


<?php echo e($maintenancerequest->tiket_no); ?><?php /**PATH C:\wamp64\www\ticket\resources\views\users\request_maintenances_It\data_table\title.blade.php ENDPATH**/ ?>